"""Vocabulário e perguntas da entrevista."""
CAREERS = {'backend': ('Desenvolvimento Back-end', 'APIs, lógica de servidores e bancos de dados'), 'frontend': ('Desenvolvimento Front-end & UI/UX', 'Interfaces, acessibilidade e experiência do usuário'), 'datascience': ('Ciência de Dados e Machine Learning', 'Estatística, modelos preditivos e análise'), 'dataeng': ('Engenharia de Dados', 'Pipelines ETL/ELT, qualidade e arquitetura de dados'), 'security': ('Cibersegurança', 'Proteção, análise de vulnerabilidades e redes'), 'devops': ('DevOps & SRE', 'CI/CD, automação e confiabilidade operacional'), 'cloud': ('Computação em Nuvem', 'Arquitetura escalável e serviços cloud'), 'mobile': ('Desenvolvimento Mobile', 'Aplicativos Android, iOS e multiplataforma'), 'qa': ('Engenharia de Qualidade e Testes (QA)', 'Testes, prevenção de defeitos e qualidade'), 'product': ('Gestão de Produtos', 'Estratégia, priorização e alinhamento com negócio')}
QUESTIONS = [
 ('math','Afinidade com matemática e estatística',['baixa','media','alta']),
 ('activity','Atividade que mais gosta',['algoritmos','interfaces','modelos','pipelines','seguranca','automacao','infraestrutura','apps','testes','estrategia']),
 ('tool','Ferramenta ou linguagem preferida',['python','javascript','java','sql','linux','cloud','flutter','testes','gestao','nenhuma']),
 ('value','Entrega de valor mais interessante',['api','experiencia','previsoes','dados_confiaveis','protecao','entrega_continua','escalabilidade','app','qualidade','negocio']),
 ('environment','Ambiente de trabalho preferido',['codigo','design','pesquisa','dados','redes','operacoes','nuvem','dispositivos','validacao','stakeholders']),
 ('goal','Objetivo profissional',['construir_sistemas','criar_interfaces','inteligencia_artificial','plataformas_dados','defender_sistemas','automatizar_entregas','arquitetar_cloud','criar_aplicativos','evitar_falhas','liderar_produto'])
]
