import streamlit as st
from knowledge import CAREERS, QUESTIONS
from engine import recommend

st.set_page_config(page_title='Consultor Inteligente de Carreiras em TI', page_icon='🧭', layout='centered')
st.title('🧭 Consultor Inteligente de Carreiras em TI')
st.caption('Sistema especialista com 40 regras SE–ENTÃO | UNIPAC Barbacena')
st.write('Responda às seis perguntas para receber uma indicação explicável de trilha profissional. É uma orientação exploratória, não um diagnóstico definitivo.')
with st.form('entrevista'):
    answers = {}
    for key, label, choices in QUESTIONS:
        answers[key] = st.selectbox(label, choices, format_func=lambda s:s.replace('_',' ').capitalize())
    submitted = st.form_submit_button('Analisar meu perfil', type='primary', use_container_width=True)
if submitted:
    result = recommend(answers)
    if result['winner'] is None:
        st.warning('Não houve regras suficientes. Tente combinar outras respostas.')
    else:
        c=result['winner']
        st.success('Trilha recomendada: '+CAREERS[c][0])
        st.write(CAREERS[c][1])
        if result['tie']:
            st.warning('Empate de pontuação: critério de desempate determinístico pela ordem das trilhas. Explore também a segunda opção.')
        st.subheader('Por que essa recomendação?')
        for e in result['reasons']:
            st.write(f"**{e['rule']}** · +{e['weight']} pontos — {e['reason']}")
        st.subheader('Pontuação das trilhas')
        st.bar_chart({CAREERS[c][0]:result['scores'][c] for c in result['ranked']})
        with st.expander('Todas as regras ativadas'):
            for e in result['evidence']:
                st.write(f"{e['rule']}: {CAREERS[e['career']][0]} (+{e['weight']}) — {e['reason']}")
