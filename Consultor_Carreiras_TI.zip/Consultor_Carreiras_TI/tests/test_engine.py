import unittest
from engine import recommend

PERSONAS = [('Analítica / Ciência de Dados', {'math': 'alta', 'activity': 'modelos', 'tool': 'python', 'value': 'previsoes', 'environment': 'pesquisa', 'goal': 'inteligencia_artificial'}, 'datascience'), ('Infraestrutura / Segurança', {'math': 'media', 'activity': 'seguranca', 'tool': 'linux', 'value': 'protecao', 'environment': 'redes', 'goal': 'defender_sistemas'}, 'security'), ('Visual / Front-end', {'math': 'baixa', 'activity': 'interfaces', 'tool': 'javascript', 'value': 'experiencia', 'environment': 'design', 'goal': 'criar_interfaces'}, 'frontend'), ('Negócios / Produto', {'math': 'media', 'activity': 'estrategia', 'tool': 'gestao', 'value': 'negocio', 'environment': 'stakeholders', 'goal': 'liderar_produto'}, 'product'), ('Engenharia de Dados', {'math': 'alta', 'activity': 'pipelines', 'tool': 'sql', 'value': 'dados_confiaveis', 'environment': 'dados', 'goal': 'plataformas_dados'}, 'dataeng')]
class TestEngine(unittest.TestCase):
    def test_personas(self):
        for name, answers, expected in PERSONAS:
            with self.subTest(name=name):
                r=recommend(answers)
                self.assertEqual(r['winner'], expected)
                self.assertGreater(len(r['reasons']),0)
    def test_invalid(self):
        with self.assertRaises(ValueError):
            recommend({})
    def test_rule_count(self):
        import inspect, engine
        methods=[name for name, _ in inspect.getmembers(engine.CareerEngine) if name.startswith('rule_')]
        self.assertGreaterEqual(len(methods),25)
if __name__ == '__main__': unittest.main()
