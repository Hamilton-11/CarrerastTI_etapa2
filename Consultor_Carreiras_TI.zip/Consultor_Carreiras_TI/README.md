# Consultor Inteligente de Carreiras em TI

Projeto acadêmico — Centro Universitário Presidente Antônio Carlos (UNIPAC Barbacena).

## Funcionalidades
- Entrevista com 6 dimensões de perfil e opções objetivas.
- Motor de inferência Experta com **40 regras cruzadas**, acionadas por fatos.
- Pontuação por regra, explicações rastreáveis e classificação das 10 carreiras.
- Interface Streamlit, gráfico comparativo e lista das regras ativadas.
- Cinco personas e testes automatizados (inclui distinção Ciência vs. Engenharia de Dados).

## Instalação
Recomendado **Python 3.10** (a biblioteca Experta é antiga; versões mais recentes podem exigir ajustes). No terminal, dentro desta pasta:

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# Linux/macOS:
# source .venv/bin/activate
python -m pip install -r requirements.txt
streamlit run app.py
```

O navegador abre a interface (geralmente em http://localhost:8501).

## Testes
```bash
python -m unittest discover -s tests -v
```

## Arquitetura
- `knowledge.py`: trilhas e perguntas.
- `engine.py`: `Answer(Fact)`, `CareerEngine(KnowledgeEngine)` e 40 métodos `@Rule`.
- `app.py`: formulário, análise, explicações e gráfico.
- `docs/matriz_decisao.csv`: matriz auditável de condições e pesos.
- `docs/personas.csv`: dados de validação.
- `tests/test_engine.py`: testes automatizados.

## Política de inferência
Cada resposta vira um fato. Uma regra dispara somente quando **todas** as suas condições coincidem; os pontos da trilha são somados. Vence a maior pontuação. Empates são explicitados e resolvidos por ordem fixa apenas para manter a interface determinística. Sem regra ativada, o sistema declara evidência insuficiente. A recomendação não é avaliação psicométrica validada nem promessa de empregabilidade.

## Limitações e melhorias
Os pesos são heurísticos definidos para fins didáticos; devem ser calibrados com especialistas e usuários. Perguntas são fixas, mas o questionário é interativo e os fatos variam conforme o usuário. A classificação pode empatar ou ficar sem evidência. Para evoluir: perguntas condicionais, banco de dados, avaliações reais e testes de usabilidade.

## Publicar no GitHub
Crie um repositório, copie os arquivos (sem `.venv`) e execute `git init`, `git add .`, `git commit -m "Projeto inicial"`; conecte ao remoto conforme as instruções do GitHub.
