"""Motor de inferência baseado em regras Experta (encadeamento para frente)."""
# Compatibilidade com versões de frozendict que removem collections.Mapping.
import collections
import collections.abc
for _name in ('Mapping', 'MutableMapping', 'Sequence'):
    if not hasattr(collections, _name):
        setattr(collections, _name, getattr(collections.abc, _name))
from experta import KnowledgeEngine, Fact, Rule
from knowledge import CAREERS, QUESTIONS

class Answer(Fact):
    """Fato da entrevista: campo e resposta."""

class CareerEngine(KnowledgeEngine):
    def __init__(self):
        super().__init__()
        self.evidence = []

    def register(self, career, weight, reason, rule_id):
        self.evidence.append({'career':career,'weight':weight,'reason':reason,'rule':rule_id})

    @Rule(Answer(field='activity', value='algoritmos'), Answer(field='value', value='api'))
    def rule_01(self):
        self.register('backend', 8, 'Interesse em algoritmos e APIs', "R01")

    @Rule(Answer(field='tool', value='java'), Answer(field='environment', value='codigo'))
    def rule_02(self):
        self.register('backend', 5, 'Afinidade com Java e programação', "R02")

    @Rule(Answer(field='goal', value='construir_sistemas'), Answer(field='activity', value='algoritmos'))
    def rule_03(self):
        self.register('backend', 7, 'Objetivo de construir sistemas', "R03")

    @Rule(Answer(field='activity', value='interfaces'), Answer(field='value', value='experiencia'))
    def rule_04(self):
        self.register('frontend', 8, 'Interfaces com foco na experiência', "R04")

    @Rule(Answer(field='tool', value='javascript'), Answer(field='environment', value='design'))
    def rule_05(self):
        self.register('frontend', 6, 'JavaScript e design', "R05")

    @Rule(Answer(field='goal', value='criar_interfaces'), Answer(field='activity', value='interfaces'))
    def rule_06(self):
        self.register('frontend', 7, 'Interesse em interfaces', "R06")

    @Rule(Answer(field='activity', value='modelos'), Answer(field='math', value='alta'))
    def rule_07(self):
        self.register('datascience', 8, 'Modelagem apoiada em matemática', "R07")

    @Rule(Answer(field='tool', value='python'), Answer(field='value', value='previsoes'))
    def rule_08(self):
        self.register('datascience', 7, 'Python para previsões', "R08")

    @Rule(Answer(field='goal', value='inteligencia_artificial'), Answer(field='environment', value='pesquisa'))
    def rule_09(self):
        self.register('datascience', 7, 'IA e investigação analítica', "R09")

    @Rule(Answer(field='activity', value='pipelines'), Answer(field='value', value='dados_confiaveis'))
    def rule_10(self):
        self.register('dataeng', 8, 'Pipelines e confiabilidade dos dados', "R10")

    @Rule(Answer(field='tool', value='sql'), Answer(field='environment', value='dados'))
    def rule_11(self):
        self.register('dataeng', 6, 'SQL e sistemas de dados', "R11")

    @Rule(Answer(field='goal', value='plataformas_dados'), Answer(field='activity', value='pipelines'))
    def rule_12(self):
        self.register('dataeng', 7, 'Construção de plataformas de dados', "R12")

    @Rule(Answer(field='activity', value='seguranca'), Answer(field='value', value='protecao'))
    def rule_13(self):
        self.register('security', 8, 'Defesa e proteção de sistemas', "R13")

    @Rule(Answer(field='tool', value='linux'), Answer(field='environment', value='redes'))
    def rule_14(self):
        self.register('security', 6, 'Linux e redes', "R14")

    @Rule(Answer(field='goal', value='defender_sistemas'), Answer(field='activity', value='seguranca'))
    def rule_15(self):
        self.register('security', 7, 'Objetivo de defender sistemas', "R15")

    @Rule(Answer(field='activity', value='automacao'), Answer(field='value', value='entrega_continua'))
    def rule_16(self):
        self.register('devops', 8, 'Automação e entrega contínua', "R16")

    @Rule(Answer(field='tool', value='linux'), Answer(field='environment', value='operacoes'))
    def rule_17(self):
        self.register('devops', 6, 'Linux e operações', "R17")

    @Rule(Answer(field='goal', value='automatizar_entregas'), Answer(field='activity', value='automacao'))
    def rule_18(self):
        self.register('devops', 7, 'Automação de entregas', "R18")

    @Rule(Answer(field='activity', value='infraestrutura'), Answer(field='value', value='escalabilidade'))
    def rule_19(self):
        self.register('cloud', 8, 'Infraestrutura escalável', "R19")

    @Rule(Answer(field='tool', value='cloud'), Answer(field='environment', value='nuvem'))
    def rule_20(self):
        self.register('cloud', 6, 'Ferramentas cloud e nuvem', "R20")

    @Rule(Answer(field='goal', value='arquitetar_cloud'), Answer(field='activity', value='infraestrutura'))
    def rule_21(self):
        self.register('cloud', 7, 'Arquitetura em nuvem', "R21")

    @Rule(Answer(field='activity', value='apps'), Answer(field='value', value='app'))
    def rule_22(self):
        self.register('mobile', 8, 'Aplicativos como entrega final', "R22")

    @Rule(Answer(field='tool', value='flutter'), Answer(field='environment', value='dispositivos'))
    def rule_23(self):
        self.register('mobile', 6, 'Flutter e dispositivos móveis', "R23")

    @Rule(Answer(field='goal', value='criar_aplicativos'), Answer(field='activity', value='apps'))
    def rule_24(self):
        self.register('mobile', 7, 'Criação de aplicativos', "R24")

    @Rule(Answer(field='activity', value='testes'), Answer(field='value', value='qualidade'))
    def rule_25(self):
        self.register('qa', 8, 'Testes e qualidade', "R25")

    @Rule(Answer(field='tool', value='testes'), Answer(field='environment', value='validacao'))
    def rule_26(self):
        self.register('qa', 6, 'Ferramentas de teste e validação', "R26")

    @Rule(Answer(field='goal', value='evitar_falhas'), Answer(field='activity', value='testes'))
    def rule_27(self):
        self.register('qa', 7, 'Prevenção de falhas', "R27")

    @Rule(Answer(field='activity', value='estrategia'), Answer(field='value', value='negocio'))
    def rule_28(self):
        self.register('product', 8, 'Estratégia e negócio', "R28")

    @Rule(Answer(field='tool', value='gestao'), Answer(field='environment', value='stakeholders'))
    def rule_29(self):
        self.register('product', 6, 'Gestão e partes interessadas', "R29")

    @Rule(Answer(field='goal', value='liderar_produto'), Answer(field='activity', value='estrategia'))
    def rule_30(self):
        self.register('product', 7, 'Liderança de produto', "R30")

    @Rule(Answer(field='activity', value='algoritmos'), Answer(field='tool', value='nenhuma'))
    def rule_31(self):
        self.register('backend', 3, 'Afinidade inicial, mesmo sem ferramenta prévia', "R31")

    @Rule(Answer(field='activity', value='interfaces'), Answer(field='tool', value='nenhuma'))
    def rule_32(self):
        self.register('frontend', 3, 'Afinidade inicial, mesmo sem ferramenta prévia', "R32")

    @Rule(Answer(field='activity', value='modelos'), Answer(field='tool', value='nenhuma'))
    def rule_33(self):
        self.register('datascience', 3, 'Afinidade inicial, mesmo sem ferramenta prévia', "R33")

    @Rule(Answer(field='activity', value='pipelines'), Answer(field='tool', value='nenhuma'))
    def rule_34(self):
        self.register('dataeng', 3, 'Afinidade inicial, mesmo sem ferramenta prévia', "R34")

    @Rule(Answer(field='activity', value='seguranca'), Answer(field='tool', value='nenhuma'))
    def rule_35(self):
        self.register('security', 3, 'Afinidade inicial, mesmo sem ferramenta prévia', "R35")

    @Rule(Answer(field='activity', value='automacao'), Answer(field='tool', value='nenhuma'))
    def rule_36(self):
        self.register('devops', 3, 'Afinidade inicial, mesmo sem ferramenta prévia', "R36")

    @Rule(Answer(field='activity', value='infraestrutura'), Answer(field='tool', value='nenhuma'))
    def rule_37(self):
        self.register('cloud', 3, 'Afinidade inicial, mesmo sem ferramenta prévia', "R37")

    @Rule(Answer(field='activity', value='apps'), Answer(field='tool', value='nenhuma'))
    def rule_38(self):
        self.register('mobile', 3, 'Afinidade inicial, mesmo sem ferramenta prévia', "R38")

    @Rule(Answer(field='activity', value='testes'), Answer(field='tool', value='nenhuma'))
    def rule_39(self):
        self.register('qa', 3, 'Afinidade inicial, mesmo sem ferramenta prévia', "R39")

    @Rule(Answer(field='activity', value='estrategia'), Answer(field='tool', value='nenhuma'))
    def rule_40(self):
        self.register('product', 3, 'Afinidade inicial, mesmo sem ferramenta prévia', "R40")


def recommend(answers):
    """Retorna trilha e explicações; não inventa correspondência quando faltam dados."""
    expected = {q[0]: set(q[2]) for q in QUESTIONS}
    for key, options in expected.items():
        if key not in answers or answers[key] not in options:
            raise ValueError(f'Resposta inválida ou ausente: {key}')
    engine = CareerEngine()
    engine.reset()
    for key, value in answers.items():
        if key in expected:
            engine.declare(Answer(field=key, value=value))
    engine.run()
    scores = {c:0 for c in CAREERS}
    for item in engine.evidence:
        scores[item['career']] += item['weight']
    ranked = sorted(scores, key=lambda c: (-scores[c], list(CAREERS).index(c)))
    winner = ranked[0] if scores[ranked[0]] > 0 else None
    return {'winner':winner,'scores':scores,'ranked':ranked,
            'reasons':[e for e in engine.evidence if e['career']==winner],
            'evidence':engine.evidence, 'tie':winner is not None and scores[ranked[0]]==scores[ranked[1]]}
